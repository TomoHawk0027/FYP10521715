import pandas as pd

df = pd.read_csv("car_price.csv") 
#df = df.dropna(subset=["price"])
print(df)

def convertCategoricalToBinary(df):
    from sklearn.preprocessing import OneHotEncoder #tried to create function for this so that I could import the process. However this did not work.
    enc = OneHotEncoder(handle_unknown='ignore')
    print(df.columns)
    colToConvert=input("Enter name of column to convert to binary: ")
    enc_df = pd.DataFrame(enc.fit_transform(df[[colToConvert]]).toarray())
    print("encdf is below")
    print(enc_df)
    lengthdf=len(enc_df.columns)
    df = df.join(enc_df)
    print(df.columns)
    print(df)

    categories=df[colToConvert].unique()


    for i in range(1,len(categories)):
       df.rename(columns={i:categories[i]}, inplace=True)
    print(df.head())



convertCategoricalToBinary(df)
#enc_df = pd.DataFrame(enc.fit_transform(df[['discount']]).toarray())
#print(enc_df)
#df = df.join(enc_df)
#print(df.columns)
#print(df)
#df=df.drop([0],axis='columns') # enc is a 4x4 matrix, only 3x3 is needed. 
#df.rename(columns={1:'None',2:'Excl. Govt. Charges',3:'Drive Away'}, inplace=True)
#print(df.head())
#df.to_csv('car_price+withnulls.csv')
#enc_df = pd.DataFrame(enc.fit_transform(df[['body']]).toarray()) #input contains NaN. OneHotEncoder cannot work with NULL values.
#print(enc_df)
#df = df.join(enc_df)
#print(df.columns)
#print(df)


#df=df.drop([0],axis='columns')
#df.rename(columns={1:'None',2:'Excl. Govt. Charges',3:'Drive Away'}, inplace=True)
#print(df.head())


