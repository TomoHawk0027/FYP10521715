#import csv
#data = analysingData(df)
#with open('car_price_stats.csv', 'w') as output_file:
#    csv_out=csv.writer(output_file)
#    #csv_out.writerow(['word','count'])
#    for row in data:
#        csv_out.writerow(row)

#with open("car_price_stats.txt", "wb") as output:

#import csv
#data = df
#with open('car_price_stats.csv', 'w') as output_file:
#    csv_out=csv.writer(output_file)
#    #csv_out.writerow(['word','count'])
#    for row in data:
#        csv_out.writerow(row)


###Export code output to txt file by rerouting sys###

#import sys

##analysingData(df)
##print('This message will be displayed on the screen.')

##original_stdout = sys.stdout # Save a reference to the original standard output

#load code output into text file by rerouting#

#with open('filename.txt', 'w') as f:
#    sys.stdout = f # Change the standard output to the file we created.
#    analysingData(df)
#    sys.stdout = original_stdout # Reset the standard output to its original value

###STATISTICS###
#from fileloadOOP import analysingData

#mean = np.mean(df["price"])
#print(mean)

#media = np.median(df["price"])
#print(media)

#mode = stats.mode(df["price"])
#print("The modal value is {} with a count of {}".format(mode.mode[0], mode.count[0]))

#vary=np.var(df["price"])
#print(vary)

#sqrt=vary**0.5
#print(sqrt)

###Next: transmission: convert to three categories: auto,manual and other
#df["transmission"].fillna("Transmission_Other",inplace=True)
#x=df['transmission'].unique()
#print(x)
#print("\n Replacing categories above with the label Transmission_Other. \n")

#df["transmission"] = df["transmission"].replace(['4cyl 1.5L Petrol', '4cyl 2.0L Turbo Petrol',
# '4cyl 1.8L Petrol', '4cyl 2.5L Petrol', '4cyl 2.0L Petrol',
# '4cyl 2.5L Turbo Petrol', '4cyl 2.2L Turbo Diesel',
# '5cyl 3.2L Turbo Diesel', '4cyl 1.5L Turbo Diesel',
# '4cyl 1.8L Turbo Diesel', '6cyl 3.7L Petrol', '6cyl 3.8L Turbo Petrol',
# '4cyl 2.3L Turbo Diesel', '6cyl 3.5L Petrol', '4cyl 2.5L S Petrol',
# '8cyl 5.6L Petrol', '4cyl 1.6L Turbo Petrol', '4cyl 1.6L Turbo Diesel',
# '4cyl 2.0L Turbo Diesel', '4cyl 1.2L Turbo Petrol',
# '4cyl 2.8L Turbo Diesel', '4cyl 3.0L Turbo Diesel', '4cyl 2.7L Petrol',
# '4cyl 2.4L Turbo Diesel', '8cyl 4.5L Turbo Diesel', '4cyl 2.4L Petrol'],'Transmission_Other')

#x=df['transmission'].unique()
#print(x)
import pandas as pd
df = pd.read_csv("carpricefixedbetter2.csv") 
df.dropna(subset=["price"]) #drop rows with null values in price column
df=df.drop(['id','title','model'],1) #
print(df)
col=list(df.columns)

for i in range(1,len(df.columns)):
    j=df[col[i]].unique()
    print(col[i],"contains ",len(j)," distinct values\n")
    
#
#Convert calender year to years old.
df["Years Old"]=2018-df["year"]
#
from sklearn.preprocessing import OneHotEncoder #tried to create function for this so that I could import the process. However this did not work.
enc = OneHotEncoder(handle_unknown='ignore')


for i in range(1,len(df.columns)):
    df[col(i)].fillna("other_Type",inplace=True)
    enc_df = pd.DataFrame(enc.fit_transform(df[[col(i)]]).toarray())
    df = df.join(enc_df)
    print(df.columns)

    categories=df[[col(i)].unique()


    #for k in range(0,len(categories)):
    #    df.rename(columns={k:categories[k]}, inplace=True)

