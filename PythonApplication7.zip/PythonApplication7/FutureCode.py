## Preview the first 5 lines of the loaded data 
#print(df)
#df=df.drop(["id","title","model"],axis='columns')

#type(df)
#analysingData(df)


#from scipy import stats #Stats module contains a large number of probability distributions as well as a growing library of statistical functions
#from patsy import dmatrices # "y ~ x1 + x2" (for dmatrices()).
#import statsmodels.api as sm #provides classes and functions for the estimation of many different statistical models,
#                             #as well as for conducting statistical tests, and statistical data exploration
#import matplotlib.pyplot as plt #mainly intended for interactive plots and simple cases of programmatic plot generation

#from splitTrainingTest import splitTrainingTest
#splitTrainingTest(df)

#import csv
#data = df
#with open('FYPHot.csv', 'w') as output_file:
#    csv_out=csv.writer(output_file)
#    #csv_out.writerow(['word','count'])
#    for row in data:
#        csv_out.writerow(row)

#df=df.drop(["id","brand","title","model"],axis='columns')
#df = df.dropna(subset=["price"])
#print(df)