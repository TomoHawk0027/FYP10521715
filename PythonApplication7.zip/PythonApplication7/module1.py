import pandas as pd
df = pd.read_csv("carpricefixedbetter2.csv") 
df.dropna(subset=["price"]) #drop rows with null values in price column
df=df.drop(['id','title','model'],1) #
print(df)
col=list(df.columns)

for i in range(1,len(df.columns)):
    j=df[col[i]].unique()
    print(col[i],"contains ",len(j)," distinct values\n")
    
#
#Convert calender year to years old.
df["Years Old"]=2018-df["year"]
#
from sklearn.preprocessing import OneHotEncoder #tried to create function for this so that I could import the process. However this did not work.
enc = OneHotEncoder(handle_unknown='ignore')

for i in range(1,len(col)):
    df[col[i]].fillna("other_Type",inplace=True)
    str=str(col[i])
    enc_df = pd.DataFrame(enc.fit_transform(df[str]).toarray())
    df = df.join(enc_df)
    print(df.columns)

    categories=df[str].unique()
    for i in range(0,len(categories)):
        df.rename(columns={i:categories[i]}, inplace=True)

print(df)
