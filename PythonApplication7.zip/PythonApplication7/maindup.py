import pandas as pd
df = pd.read_csv("car_price.csv") 
df.dropna(subset=["price"])
df=df.drop(['id','title','model'],1)
print(df)
#
#Convert calender year to years old.
df["Years Old"]=2018-df["year"]
#
from sklearn.preprocessing import OneHotEncoder #tried to create function for this so that I could import the process. However this did not work.
enc = OneHotEncoder(handle_unknown='ignore')


enc_df = pd.DataFrame(enc.fit_transform(df[['brand']]).toarray())
print(enc_df)
df = df.join(enc_df)
print(df.columns)
print(df)
categories=df['brand'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)
print(df)

enc_df = pd.DataFrame(enc.fit_transform(df[['discount']]).toarray())
print(enc_df)
df = df.join(enc_df)
print(df.columns)
print(df)
categories=df['discount'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)
print(df)

df["body"].fillna("other_Body_Type",inplace=True)#input contains NaN. OneHotEncoder cannot work with NULL values. So I replaced them.
enc_df = pd.DataFrame(enc.fit_transform(df[['body']]).toarray()) 
print(enc_df)
df = df.join(enc_df)
print(df.columns)
print(df)
categories=df['body'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)
print(df.head())

enc_df = pd.DataFrame(enc.fit_transform(df[['seller']]).toarray()) 
print(enc_df)
df = df.join(enc_df)
print(df.columns)
print(df)
categories=df['seller'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)
print(df.head())

##Next: transmission: convert to three categories: auto,manual and other
df["transmission"].fillna("Transmission_Other",inplace=True)
x=df['transmission'].unique()
print(x)
print("\n Replacing categories above with the label Transmission_Other. \n")

df["transmission"] = df["transmission"].replace(['4cyl 1.5L Petrol', '4cyl 2.0L Turbo Petrol',
 '4cyl 1.8L Petrol', '4cyl 2.5L Petrol', '4cyl 2.0L Petrol',
 '4cyl 2.5L Turbo Petrol', '4cyl 2.2L Turbo Diesel',
 '5cyl 3.2L Turbo Diesel', '4cyl 1.5L Turbo Diesel',
 '4cyl 1.8L Turbo Diesel', '6cyl 3.7L Petrol', '6cyl 3.8L Turbo Petrol',
 '4cyl 2.3L Turbo Diesel', '6cyl 3.5L Petrol', '4cyl 2.5L S Petrol',
 '8cyl 5.6L Petrol', '4cyl 1.6L Turbo Petrol', '4cyl 1.6L Turbo Diesel',
 '4cyl 2.0L Turbo Diesel', '4cyl 1.2L Turbo Petrol',
 '4cyl 2.8L Turbo Diesel', '4cyl 3.0L Turbo Diesel', '4cyl 2.7L Petrol',
 '4cyl 2.4L Turbo Diesel', '8cyl 4.5L Turbo Diesel', '4cyl 2.4L Petrol'],'Transmission_Other')

x=df['transmission'].unique()
print(x)

enc_df = pd.DataFrame(enc.fit_transform(df[["transmission"]]).toarray()) 
print(enc_df)
df = df.join(enc_df)
print(df.columns)
print(df)

categories=df["transmission"].unique()
print(len(categories))
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)
print(df.head())



#States-onehotencoder
x=df["state"].unique()
print(x)

enc_df = pd.DataFrame(enc.fit_transform(df[["state"]]).toarray()) 
print(enc_df)
df = df.join(enc_df)
print(df.columns)
print(df)

categories=df["state"].unique()
print(len(categories))
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)
print(df.head())

#Drop now redundent columns
print("DROPPING the following columns as they are now redundent: \nyear, brand, discount, body, seller, transmission, state.\n")
df=df.drop(['brand', 'discount', 'body', 'seller', 'transmission', 'state','year'],1)

#engine problem
categories=df["engine"].unique()
print(len(categories))
print("\n")
#175 different categorical values - big problem, needs resolution


#Write dataframe df to csv
df.to_csv('car_price_dataCleansed.csv',index=False)


#df=df.drop([0],axis='columns')
#df.rename(columns={1:'None',2:'Excl. Govt. Charges',3:'Drive Away'}, inplace=True)
#print(df.head())



