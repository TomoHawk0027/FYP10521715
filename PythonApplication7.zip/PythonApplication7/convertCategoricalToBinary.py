import pandas as pd
import numpy as np

def convertCategoricalToBinary(df):
    from sklearn.preprocessing import OneHotEncoder
    enc = OneHotEncoder(handle_unknown='ignore')
    colToConvert = input("Enter column name to use oneHotEncoder on: ")
    enc_df = pd.DataFrame(enc.fit_transform(df[[colToConvert]]).toarray())
    print(enc_df)
    df = df.join(enc_df)
    print(df.columns)
    print(df)
    df.rename(columns={0:'honda',1:'mazda',2:'nissan',3:'toyota'}, inplace=True)

#dfr=[1,2,3,4,5]
#convertCategoricalToBinary(dfr)

#from module2 import convertCategoricalToBinary
#convertCategoricalToBinary(df)