import pandas as pd
df = pd.read_csv("carpricefixedbetter2.csv") 
df.dropna(subset=["price"]) #drop rows with null values in price column
df=df.drop(['id','title','model'],1) #
print(df)
col=list(df.columns)

for i in range(1,len(df.columns)):
    j=df[col[i]].unique()
    print(col[i],"contains ",len(j)," distinct values\n")
    
#
#Convert calender year to years old.
df["Years Old"]=2018-df["year"]
#
from sklearn.preprocessing import OneHotEncoder #tried to create function for this so that I could import the process. However this did not work.
enc = OneHotEncoder(handle_unknown='ignore')


enc_df = pd.DataFrame(enc.fit_transform(df[['brand']]).toarray())
df = df.join(enc_df)
print(df.columns)

categories=df['brand'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)

enc_df = pd.DataFrame(enc.fit_transform(df[['discount']]).toarray())
df = df.join(enc_df)
print(df.columns)
categories=df['discount'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)

df["body"].fillna("other_Body_Type",inplace=True)#input contains NaN. OneHotEncoder cannot work with NULL values. So I replaced them.
enc_df = pd.DataFrame(enc.fit_transform(df[['body']]).toarray()) 

df = df.join(enc_df)
print(df.columns)

categories=df['body'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)

enc_df = pd.DataFrame(enc.fit_transform(df[['seller']]).toarray()) 

df = df.join(enc_df)
print(df.columns)

categories=df['seller'].unique()
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)



df["transmission"].fillna("Transmission_Other",inplace=True)
enc_df = pd.DataFrame(enc.fit_transform(df[["transmission"]]).toarray()) 

df = df.join(enc_df)
print(df.columns)


categories=df["transmission"].unique()
print(len(categories))
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)


#Fuel
df["Fuel"].fillna("not_known",inplace=True)#input contains NaN. OneHotEncoder cannot work with NULL values. So I replaced them.
enc_df = pd.DataFrame(enc.fit_transform(df[["Fuel"]]).toarray()) 

df = df.join(enc_df)
print(df.columns)


categories=df["Fuel"].unique()
print(len(categories))
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)


#States-onehotencoder
enc_df = pd.DataFrame(enc.fit_transform(df[["state"]]).toarray()) 

df = df.join(enc_df)
print(df.columns)


categories=df["state"].unique()
print(len(categories))
for i in range(0,len(categories)):
    df.rename(columns={i:categories[i]}, inplace=True)


#Drop now redundent columns
print("DROPPING the following columns as they are now redundent: \nyear, brand, discount, body, seller, transmission, state, Fuel, Colour.\n")
df=df.drop(['brand', 'discount', 'body', 'seller', 'transmission', 'state','year', 'Fuel','Colour'],1)

#engine problem
#categories=df["engine"].unique()
#print(len(categories))
#print("\n")
#77 different categorical values - big problem, needs resolution

#fix litres col

#Write dataframe df to csv
df.to_csv('car_price_dataCleansed.csv',index=False)


#df=df.drop([0],axis='columns')
#df.rename(columns={1:'None',2:'Excl. Govt. Charges',3:'Drive Away'}, inplace=True)
#print(df.head())



