﻿import pandas as pd
import pypyodbc as py
import datetime
df = pd.read_csv("car_price.csv") 
# Preview the first 5 lines of the loaded data 
print(df.head())


# Read data from csv file into a dataFrame
def readToDataFrame(filename):
    return pd.read_csv(filename)
def analysingData(df):
    print("Analysing Data...")
    outputTotalRowsAndColumns(df) #Elisa
    outputNumberOfNonNullRowsByColumn(df) #monika 
    outputNumberOfNullValuesByColumn(df) #Thomas
    outputNumberOfNullValuesForAllColumns(df) # Fintan
    outputNumberOfDuplicateRows(df) # Fintan
    input("Data Analysis Complete, Press Enter to continue")
    print()


def outputTotalRowsAndColumns(df):
    print("1. The number of rows and columns in the dataframe, 'df' is: ", df.shape)
    print()


def outputNumberOfNonNullRowsByColumn(df):
    print("2. List of the number of non-null values contained in each column: ", df.count(axis=0, level=None, numeric_only=False))
    print()


def outputNumberOfNullValuesByColumn(df):
    print("3. List of the number of null values contained in each column: ", df.isnull().sum(axis = 0))
    print()


def outputNumberOfNullValuesForAllColumns(df):
    print("4. Number Of Null Values For All Columns : ", df.isnull().sum().sum())
    print()


def outputNumberOfDuplicateRows(df):
    print("5. Number Of Duplicate Rows : ", len(df)-len(df.drop_duplicates()))
    print()