import pandas as pd

df = pd.read_csv("car_price.csv")
print(df.dtypes)
print("\n")
print(df.info)
print("\n")
print(df.describe)
